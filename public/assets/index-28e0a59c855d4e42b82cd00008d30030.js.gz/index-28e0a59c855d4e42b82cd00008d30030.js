(function() {
  $(function() {});

}).call(this);
